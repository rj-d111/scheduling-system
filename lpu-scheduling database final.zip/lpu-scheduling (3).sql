-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2024 at 04:43 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lpu-scheduling`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_enrollment`
--

CREATE TABLE `tbl_enrollment` (
  `enrollment_id` int(11) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `subject_section_id` int(11) NOT NULL,
  `academic_year` int(11) NOT NULL,
  `semester` enum('first','second','summer') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty`
--

CREATE TABLE `tbl_faculty` (
  `faculty_id` int(11) NOT NULL,
  `faculty_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `department` enum('CLAE','COECSA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_faculty`
--

INSERT INTO `tbl_faculty` (`faculty_id`, `faculty_name`, `email`, `password`, `department`) VALUES
(1, 'Mr. Angcaya Aldwin Karlo', 'angcaya@lpunetwork.edu.ph', '$2a$12$hBX4.tC8shaCRdyW5r6vWe4GmH/RX1JyB2C4zNZAQ/88A6wxUbS2m', 'COECSA'),
(2, 'Ms. Pocaan Alyssa Paola', 'pocaan@lpunetwork.edu.ph', '$2a$12$OnyLXZfgX..r.6bsfodv8O/GQy645IlwyPDQA00M1P/LzbNu9aPfm', 'COECSA'),
(3, 'Mr. Añonuevo Michael Jeffrey', 'anonuevo@lpunetwork.edu.ph', '$2a$12$zPlldUBVmYVeSCpp4DLsV.Uy2AyrRjepa2bM/WARJAMNO/ico.8hG', 'COECSA'),
(4, 'Mr. Mendoza Genson Poblete', 'mendoza@lpunetwork.edu.ph', '$2a$12$Ox0gwWtnh.2Rsu.HMsUajeupR8ZAEfuflunmpO1PhJQfQDxOywU7W', 'COECSA'),
(5, 'Ms. Menta* Amanda Jane C.', 'menta@lpunetwork.edu.ph', '$2a$12$Cvt3/504eMMYJrs4oyQynOG9V.MBd1qlFPYKBjvulZbDnAqQl8Qhq', 'COECSA'),
(6, 'Ms. Nsubuga Elizabeth Sanyu', 'nsubuga@lpunetwork.edu.ph', '$2a$12$ipvOWKu0NEjSz8IRDiAggO3MmikqkCBqjrDSP3fRFPq2H9eOm53p6', 'COECSA'),
(7, 'Mr. Frondozo Manzaldo', 'frondozo@lpunetwork.edu.ph', '$2a$12$VTYbW9VCAYewnavIawdUPueMoXak0o1jpERDsDmM/bSCa4vcPodXq\n', 'CLAE');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty_assignments`
--

CREATE TABLE `tbl_faculty_assignments` (
  `faculty_assignments_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `subject_section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_faculty_assignments`
--

INSERT INTO `tbl_faculty_assignments` (`faculty_assignments_id`, `faculty_id`, `subject_section_id`) VALUES
(1, 1, 1),
(2, 1, 10),
(3, 3, 4),
(4, 3, 12),
(5, 7, 16),
(6, 4, 5),
(7, 4, 13),
(8, 5, 6),
(9, 5, 14),
(10, 6, 7),
(11, 6, 15),
(12, 2, 3),
(13, 2, 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE `tbl_schedule` (
  `schedule_id` int(11) NOT NULL,
  `subject_section_id` int(11) NOT NULL,
  `day` enum('M','T','W','TH','F','S') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `room_no` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_schedule`
--

INSERT INTO `tbl_schedule` (`schedule_id`, `subject_section_id`, `day`, `start_time`, `end_time`, `room_no`) VALUES
(1, 1, 'F', '10:00:00', '12:00:00', 'L-302'),
(2, 1, 'F', '13:00:00', '16:00:00', 'C-204'),
(3, 10, 'T', '10:00:00', '13:00:00', 'C-202'),
(4, 10, 'TH', '11:00:00', '13:00:00', 'C-703'),
(5, 11, 'M', '16:00:00', '18:00:00', 'C-201'),
(6, 11, 'W', '16:00:00', '19:00:00', 'C-201'),
(7, 12, 'M', '07:00:00', '10:00:00', 'C-201'),
(8, 12, 'W', '07:00:00', '09:00:00', 'L-205'),
(9, 13, 'T', '13:30:00', '16:30:00', 'C-204'),
(10, 13, 'TH', '14:00:00', '16:00:00', 'L-301'),
(11, 14, 'M', '11:00:00', '13:00:00', 'C-703'),
(12, 14, 'W', '10:00:00', '13:00:00', 'C-202'),
(13, 15, 'M', '13:00:00', '14:30:00', 'C-702'),
(14, 15, 'W', '13:00:00', '14:30:00', 'C-702'),
(15, 16, 'T', '08:30:00', '10:00:00', 'C-605'),
(16, 16, 'TH', '08:30:00', '10:00:00', 'L-206');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_school_head`
--

CREATE TABLE `tbl_school_head` (
  `school_head_id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_school_head`
--

INSERT INTO `tbl_school_head` (`school_head_id`, `first_name`, `last_name`, `email`, `password`) VALUES
(1, 'Louisse', 'Red', 'red@lpunetwork.edu.ph', '$2y$10$.HfiCmL3EHajxxZCG4W8i.rNihaXYyyNP0c/Hi/lBCWPohNrtrFSK');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_section`
--

CREATE TABLE `tbl_section` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_section`
--

INSERT INTO `tbl_section` (`section_id`, `section_name`) VALUES
(1, 'IT 301'),
(2, 'IT 302');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `program` varchar(255) NOT NULL,
  `semester` enum('first','second','summer') NOT NULL,
  `academic_year` varchar(255) NOT NULL,
  `year_standing` int(11) NOT NULL,
  `status` enum('regular','irregular') NOT NULL,
  `allowed_units` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student`
--

INSERT INTO `tbl_student` (`student_id`, `first_name`, `last_name`, `email`, `password`, `date_of_birth`, `program`, `semester`, `academic_year`, `year_standing`, `status`, `allowed_units`) VALUES
('2021-2-55555', 'Leihnard', 'Aragoza', 'leihnard@lpunetwork.edu.ph', '$2a$12$ZPsEa0rmW1Awr7M23PZN4ed98z1GRuOwdU5ELKecM9px/FplDnGrC', '1999-11-01', 'Bachelor of Science in Information Technology', 'first', '2023-2024', 3, 'regular', 24);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student_assignments`
--

CREATE TABLE `tbl_student_assignments` (
  `student_assignments_id` int(11) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `subject_section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_student_assignments`
--

INSERT INTO `tbl_student_assignments` (`student_assignments_id`, `student_id`, `subject_section_id`) VALUES
(1, '2021-2-55555', 1),
(2, '2021-2-55555', 10),
(3, '2021-2-55555', 11),
(4, '2021-2-55555', 12),
(5, '2021-2-55555', 13),
(6, '2021-2-55555', 14),
(7, '2021-2-55555', 15),
(8, '2021-2-55555', 16);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE `tbl_subjects` (
  `subject_code` varchar(255) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `department` enum('CLAE','COECSA') NOT NULL,
  `year_standing` int(11) DEFAULT NULL,
  `semester_offering` enum('first','second','summer') DEFAULT NULL,
  `lec` int(11) NOT NULL,
  `lab` int(11) NOT NULL,
  `units` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`subject_code`, `subject_name`, `department`, `year_standing`, `semester_offering`, `lec`, `lab`, `units`) VALUES
('CPHN01C', 'Quality Consciousness, Processes and Habits', 'COECSA', 1, 'first', 3, 0, 3),
('DCSN06C', 'Applications Development and Emerging Technologies', 'COECSA', 3, 'first', 2, 1, 3),
('DCSN07C', 'Social Issues and Professional Practice', 'COECSA', 1, 'second', 3, 0, 3),
('ELECL3C*', 'ICT Elective 3 (Mobile Programming)', 'COECSA', 3, 'first', 2, 1, 3),
('ENGL01G', 'Purposive Communication', 'CLAE', NULL, NULL, 3, 0, 3),
('ETHN01G', 'Ethics', 'CLAE', NULL, NULL, 3, 0, 3),
('FLAN01G', 'Foreign Language', 'CLAE', NULL, NULL, 3, 0, 3),
('FLIN01G', 'Kontekstwalisadong Komunikasyon Sa Filipino', 'CLAE', NULL, NULL, 3, 0, 3),
('FLIN02G', 'Filipino Sa Iba\'t Ibang Disiplina', 'CLAE', NULL, NULL, 3, 0, 3),
('HUMN02G', 'Art Appreciation', 'CLAE', NULL, NULL, 3, 0, 3),
('ICTN05C', 'Integrative Programming and Technologies', 'COECSA', 3, 'first', 2, 1, 3),
('ICTN18C', 'Management Information Systems', 'COECSA', 3, 'first', 2, 1, 3),
('IIEN01G', 'Integrated Image Enhancement and Career Preparation', 'COECSA', 3, 'second', 3, 0, 3),
('ITEN02C', 'Discrete Mathematics', 'COECSA', 1, 'second', 3, 0, 3),
('ITEN04C', 'Quantitative Methods', 'COECSA', 3, 'second', 3, 0, 3),
('ITEN06C', 'Networking 2', 'COECSA', 3, 'first', 2, 1, 3),
('ITEN08C', 'Systems Integration and Architecture 1', 'COECSA', 3, 'first', 2, 1, 3),
('JPLN01G', 'JPL Life and His Works / JPL: Buhay, Gawa at mga Akda', 'CLAE', NULL, NULL, 3, 0, 3),
('LITN01G', 'The Literatures of the Philippines', 'CLAE', NULL, NULL, 3, 0, 3),
('LWRN01G', 'Life and Works of Rizal', 'CLAE', NULL, NULL, 3, 0, 3),
('MATH01G', 'Mathematics in the Modern World', 'COECSA', NULL, NULL, 3, 0, 3),
('MATN07G', 'Pre-Calculus & Functional Mathematics', 'COECSA', 2, 'first', 3, 0, 3),
('PSTN01E', 'Probability & Statistics', 'COECSA', 3, 'first', 3, 0, 3),
('RMCN01C', 'Research Methods in Computing', 'COECSA', 3, 'second', 3, 0, 3),
('RPHS01G', 'Readings in Philippine History', 'CLAE', NULL, NULL, 3, 0, 3),
('STSN11G', 'Science, Technology and Society', 'CLAE', NULL, NULL, 3, 0, 3),
('TCWN01G', 'The Contemporary World', 'CLAE', NULL, NULL, 3, 0, 3),
('TECN01C', 'Technopreneurship', 'COECSA', 4, 'first', 3, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subject_section`
--

CREATE TABLE `tbl_subject_section` (
  `subject_section_id` int(11) NOT NULL,
  `subject_code` varchar(255) NOT NULL,
  `section_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_subject_section`
--

INSERT INTO `tbl_subject_section` (`subject_section_id`, `subject_code`, `section_id`) VALUES
(1, 'DCSN06C', 1),
(2, 'ELECL3C*', 1),
(3, 'ICTN05C', 1),
(4, 'ICTN18C', 1),
(5, 'ITEN06C', 1),
(6, 'ITEN08C', 1),
(7, 'PSTN01E', 1),
(8, 'RPHS01G', 1),
(9, 'DCSN06C', 2),
(10, 'ELECL3C*', 2),
(11, 'ICTN05C', 2),
(12, 'ICTN18C', 2),
(13, 'ITEN06C', 2),
(14, 'ITEN08C', 2),
(15, 'PSTN01E', 2),
(16, 'RPHS01G', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_enrollment`
--
ALTER TABLE `tbl_enrollment`
  ADD PRIMARY KEY (`enrollment_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_section_id` (`subject_section_id`);

--
-- Indexes for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `tbl_faculty_assignments`
--
ALTER TABLE `tbl_faculty_assignments`
  ADD PRIMARY KEY (`faculty_assignments_id`),
  ADD KEY `faculty_id` (`faculty_id`),
  ADD KEY `subject_section_id` (`subject_section_id`);

--
-- Indexes for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `subject_section_id` (`subject_section_id`);

--
-- Indexes for table `tbl_school_head`
--
ALTER TABLE `tbl_school_head`
  ADD PRIMARY KEY (`school_head_id`);

--
-- Indexes for table `tbl_section`
--
ALTER TABLE `tbl_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `tbl_student_assignments`
--
ALTER TABLE `tbl_student_assignments`
  ADD PRIMARY KEY (`student_assignments_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `subject_section_id` (`subject_section_id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`subject_code`);

--
-- Indexes for table `tbl_subject_section`
--
ALTER TABLE `tbl_subject_section`
  ADD PRIMARY KEY (`subject_section_id`),
  ADD KEY `subject_code` (`subject_code`),
  ADD KEY `tbl_subject_section_ibfk_2` (`section_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_enrollment`
--
ALTER TABLE `tbl_enrollment`
  MODIFY `enrollment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_faculty_assignments`
--
ALTER TABLE `tbl_faculty_assignments`
  MODIFY `faculty_assignments_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_school_head`
--
ALTER TABLE `tbl_school_head`
  MODIFY `school_head_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_section`
--
ALTER TABLE `tbl_section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_student_assignments`
--
ALTER TABLE `tbl_student_assignments`
  MODIFY `student_assignments_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_subject_section`
--
ALTER TABLE `tbl_subject_section`
  MODIFY `subject_section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_enrollment`
--
ALTER TABLE `tbl_enrollment`
  ADD CONSTRAINT `tbl_enrollment_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student` (`student_id`),
  ADD CONSTRAINT `tbl_enrollment_ibfk_2` FOREIGN KEY (`subject_section_id`) REFERENCES `tbl_subject_section` (`subject_section_id`);

--
-- Constraints for table `tbl_faculty_assignments`
--
ALTER TABLE `tbl_faculty_assignments`
  ADD CONSTRAINT `tbl_faculty_assignments_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `tbl_faculty` (`faculty_id`),
  ADD CONSTRAINT `tbl_faculty_assignments_ibfk_2` FOREIGN KEY (`subject_section_id`) REFERENCES `tbl_subject_section` (`subject_section_id`);

--
-- Constraints for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD CONSTRAINT `tbl_schedule_ibfk_1` FOREIGN KEY (`subject_section_id`) REFERENCES `tbl_subject_section` (`subject_section_id`);

--
-- Constraints for table `tbl_student_assignments`
--
ALTER TABLE `tbl_student_assignments`
  ADD CONSTRAINT `tbl_student_assignments_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `tbl_student` (`student_id`),
  ADD CONSTRAINT `tbl_student_assignments_ibfk_2` FOREIGN KEY (`subject_section_id`) REFERENCES `tbl_subject_section` (`subject_section_id`);

--
-- Constraints for table `tbl_subject_section`
--
ALTER TABLE `tbl_subject_section`
  ADD CONSTRAINT `tbl_subject_section_ibfk_1` FOREIGN KEY (`subject_code`) REFERENCES `tbl_subjects` (`subject_code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_subject_section_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `tbl_section` (`section_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
