-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2023 at 02:08 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scheduling-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_course`
--

CREATE TABLE `tbl_course` (
  `course_id` varchar(10) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `department` enum('CLAE','COECSA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_course`
--

INSERT INTO `tbl_course` (`course_id`, `subject_name`, `department`) VALUES
('CPHN01C', 'Quality Consciousness, Processes and Habits', 'COECSA'),
('DCSN07C', 'Social Issues and Professional Practice', 'COECSA'),
('ENGL01G', 'Purposive Communication', 'CLAE'),
('ETHN01G', 'Ethics', 'CLAE'),
('FLAN01G', 'Foreign Language', 'CLAE'),
('FLIN01G', 'Kontekstwalisadong Komunikasyon Sa Filipino', 'CLAE'),
('FLIN02G', 'Filipino Sa Iba\'t Ibang Disiplina', 'CLAE'),
('HUMN02G', 'Art Appreciation', 'CLAE'),
('ICTN18C', 'Management Information Systems', 'COECSA'),
('IIEN01G', 'Integrated Image Enhancement and Career Preparation', 'COECSA'),
('ITEN02C', 'Discrete Mathematics', 'COECSA'),
('ITEN04C', 'Quantitative Methods', 'COECSA'),
('JPLN01G', 'JPL Life and His Works / JPL: Buhay, Gawa at mga Akda', 'CLAE'),
('LITN01G', 'The Literatures of the Philippines', 'CLAE'),
('LWRN01G', 'Life and Works of Rizal', 'CLAE'),
('MATH01G', 'Mathematics in the Modern World', 'COECSA'),
('MATN07G', 'Pre-Calculus & Functional Mathematics', 'COECSA'),
('PSTN01E', 'Probability & Statistics', 'COECSA'),
('RMCN01C', 'Research Methods in Computing', 'COECSA'),
('RPHS01G', 'Readings in Philippine History', 'CLAE'),
('STSN11G', 'Science, Technology and Society', 'CLAE'),
('TCWN01G', 'The Contemporary World', 'CLAE'),
('TECN01C', 'Technopreneurship', 'COECSA');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faculty`
--

CREATE TABLE `tbl_faculty` (
  `faculty_id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `department` enum('CLAE','COECSA') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_faculty`
--

INSERT INTO `tbl_faculty` (`faculty_id`, `email`, `password`, `first_name`, `last_name`, `department`) VALUES
(1, 'nosneg@lpunetwork.edu.ph', '$2a$12$vTirZ9BmA0WWoHP0GrGbO.viMAOTISKXa3TKx3atLknh0km5Lf9OS', 'Genson', 'Mendoza', 'COECSA'),
(2, 'frondozo@lpunetwork.edu.ph', '$2a$12$oPUIpBvTt0B5i/bj126EvuC15VMXqQYqD2lECJY0cBmxdLQcbY2c2', 'Manzaldo', 'Frondozo', 'CLAE'),
(3, 'jeffrey@gmail.com', '$2a$12$5CjlJRrf.qwVY9i8dLr4Ou84fBWuloEtopJhu/nlKsZbdaTYK7/2G', 'Jeffrey', 'Añonuevo', 'COECSA');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_schedule`
--

CREATE TABLE `tbl_schedule` (
  `schedule_id` int(11) NOT NULL,
  `course_id` varchar(255) NOT NULL,
  `faculty` varchar(255) NOT NULL,
  `lec` int(11) NOT NULL,
  `lab` int(11) NOT NULL,
  `units` int(255) NOT NULL,
  `description` text NOT NULL,
  `schedule` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_schedule`
--

INSERT INTO `tbl_schedule` (`schedule_id`, `course_id`, `faculty`, `lec`, `lab`, `units`, `description`, `schedule`) VALUES
(1, 'DCSN06C', 'Mr. Angcaya Aldwin Karlo', 2, 1, 3, 'Applications Development and Emerging Technologies', 'IT 301 - IT 301 - F 01:00PM-04:00PM C-204/F 10:30AM-12:30PM A-302'),
(2, 'ELECL3C*', 'Mr. Angcaya Aldwin Karlo', 2, 1, 3, 'ICT Elective 3 (Mobile Programming)', 'IT 302 - IT 302 - T 10:00AM-01:00PM S209/TH 11:00AM-01:00PM C-703'),
(3, 'ICTN05C', 'Ms. Pocaan Alyssa Paola', 2, 1, 3, 'Integrative Programming and Technologies', 'IT 302 - IT 302 - M 04:30PM-06:00PM C-201/W 04:30PM-06:00PM C-201'),
(4, 'ICTN18C', 'Mr. Añonuevo Michael Jeffrey', 2, 1, 3, 'Management Information Systems', 'IT 302 - IT 302 - M 07:00AM-10:00AM C-201/W 07:00AM-09:00AM A-205'),
(5, 'ITEN06C', 'Mr. Mendoza Genson Poblete', 2, 1, 3, 'Networking 2', 'IT 302 - IT 302 - T 01:30PM-04:30PM C-204/TH 02:00PM-04:00PM A-301'),
(6, 'ITEN08C', 'Ms. Menta* Amanda Jane C.', 2, 1, 3, 'Systems Integration and Architecture 1', 'IT 302 - IT 302 - M 11:00AM-01:00PM C-703/W 10:00AM-01:00PM TBA'),
(7, 'PSTN01E', 'Ms. Nsubuga Elizabeth Sanyu', 3, 0, 3, 'Probability & Statistics', 'IT 302 - IT 302 - M 01:00PM-02:30PM C-702/W 01:00PM-02:30PM C-702'),
(8, 'RPHS01G', 'Mr. Frondozo Manzaldo', 3, 0, 3, 'Readings in Philippine History', 'IT 302 - IT 302 - T 08:30AM-10:00AM C-605/TH 08:30AM-10:00AM A-206');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_school_head`
--

CREATE TABLE `tbl_school_head` (
  `school_head_id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_school_head`
--

INSERT INTO `tbl_school_head` (`school_head_id`, `full_name`, `email`, `password`) VALUES
(1, 'Leihnard Aragoza', 'leihnard@lpunetwork.edu.ph', '$2y$10$m3FX8lbCvhDh2MnAzKyXluJ8G9zQOxFjbKoN20KhsmUok/G3pkGDy');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_student`
--

CREATE TABLE `tbl_student` (
  `student_id` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `program` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `status` enum('regular','irregular') NOT NULL,
  `year_standing` enum('first','second','third','fourth','fifth') NOT NULL,
  `section` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_course`
--
ALTER TABLE `tbl_course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `tbl_school_head`
--
ALTER TABLE `tbl_school_head`
  ADD PRIMARY KEY (`school_head_id`);

--
-- Indexes for table `tbl_student`
--
ALTER TABLE `tbl_student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_faculty`
--
ALTER TABLE `tbl_faculty`
  MODIFY `faculty_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_schedule`
--
ALTER TABLE `tbl_schedule`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_school_head`
--
ALTER TABLE `tbl_school_head`
  MODIFY `school_head_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
